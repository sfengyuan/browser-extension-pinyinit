# Pinyin It

This is the source code of a browser extension.

# How to build

This project is relied on

```
Linux or Windows subsystem linux
npm 6.9.0
node v11.13.0
```

Donwload or run

```
git clone git@github.com:jacobsun/browser-extension-pinyinit.git

cd the project

npm install

npm build // produce extension source file

npm pack // build and package source file to zip
```

# License
MIT
